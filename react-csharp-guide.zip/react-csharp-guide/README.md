# C# 개발자를 위한 React 가이드

Vite + React(JavaScript)로 만든 학습용 프로젝트입니다.

## 실행

```powershell
npm install
npm run dev
```

터미널에 표시되는 주소(보통 `http://localhost:5173`)를 브라우저에서 엽니다.

## 먼저 볼 파일

1. `src/main.jsx` — React 시작 지점
2. `src/App.jsx` — 화면, 상태, 이벤트, 반복 출력
3. `src/styles.css` — 화면 디자인

## 코드에서 확인할 React 기능

- `useState`: 화면에서 변경되는 값 보관
- `useMemo`: 검색 결과 계산
- `onClick`, `onChange`: 이벤트 연결
- `map`: 배열을 화면 목록으로 출력
- 조건부 렌더링: `조건 && <화면 />`
- Props: `CodeBlock` 컴포넌트에 값 전달
