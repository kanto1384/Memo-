import { useMemo, useState } from "react";

// 가이드에 표시할 데이터입니다.
// 항목을 추가하려면 아래 배열에 객체 하나를 더 넣으면 됩니다.
const guideItems = [
  {
    category: "JavaScript",
    title: "변수 선언",
    keywords: "타입 var let const",
    description: "값이 바뀌지 않으면 const, 다시 대입해야 하면 let을 사용합니다.",
    csharp: `string name = "홍길동";\nint count = 0;\ncount += 1;`,
    react: `const name = "홍길동";\nlet count = 0;\ncount += 1;`,
    point: "const는 변수에 다른 값을 다시 넣지 못하게 합니다.",
  },
  {
    category: "JavaScript",
    title: "함수 선언과 호출",
    keywords: "메서드 function 화살표 함수 호출",
    description: "JavaScript에서는 클래스 밖에도 함수를 자유롭게 만들 수 있습니다.",
    csharp: `int Add(int a, int b)\n{\n    return a + b;\n}\n\nint result = Add(10, 20);`,
    react: `function add(a, b) {\n  return a + b;\n}\n\nconst result = add(10, 20);`,
    point: "호출 방법은 C#과 동일하게 함수이름(매개변수) 형태입니다.",
  },
  {
    category: "JavaScript",
    title: "if 조건문",
    keywords: "if else 조건 삼항 switch 비교",
    description: "if 문법은 C#과 거의 같고, JSX 안에서는 삼항 연산자를 자주 사용합니다.",
    csharp: `if (count > 0)\n{\n    message = "있음";\n}\nelse\n{\n    message = "없음";\n}`,
    react: `if (count > 0) {\n  message = "있음";\n} else {\n  message = "없음";\n}\n\nconst text = count > 0 ? "있음" : "없음";`,
    point: "===는 값과 자료형까지 비교합니다. ==보다 ===를 기본으로 사용합니다.",
  },
  {
    category: "JavaScript",
    title: "반복문과 배열",
    keywords: "for foreach map filter where select 반복 목록 배열",
    description: "일반 반복은 forEach, 화면 목록은 map, 조건 추출은 filter가 자주 사용됩니다.",
    csharp: `foreach (string name in names)\n{\n    Console.WriteLine(name);\n}\n\nvar active = users.Where(x => x.IsActive);`,
    react: `names.forEach((name) => {\n  console.log(name);\n});\n\nconst active = users.filter((x) => x.isActive);\nconst rows = names.map((name) => <li>{name}</li>);`,
    point: "map은 각 데이터를 JSX로 바꾸어 화면 목록을 만드는 핵심 함수입니다.",
  },
  {
    category: "JavaScript",
    title: "객체와 배열",
    keywords: "class object List 객체 배열 push",
    description: "간단한 데이터는 클래스를 만들기보다 객체 리터럴로 표현하는 경우가 많습니다.",
    csharp: `var user = new User\n{\n    Id = 1,\n    Name = "병찬"\n};\n\nvar users = new List<User>();`,
    react: `const user = {\n  id: 1,\n  name: "병찬"\n};\n\nconst users = [];\nusers.push(user);`,
    point: "객체 값은 user.name 형태로 읽습니다.",
  },
  {
    category: "JavaScript",
    title: "비동기와 API 호출",
    keywords: "async await fetch API HttpClient 서버 통신",
    description: "async/await는 C#과 비슷하고, fetch가 HttpClient와 비슷한 역할을 합니다.",
    csharp: `var response = await httpClient.GetAsync(url);\nvar json = await response.Content.ReadAsStringAsync();`,
    react: `const response = await fetch(url);\nif (!response.ok) {\n  throw new Error("요청 실패");\n}\nconst data = await response.json();`,
    point: "fetch 결과는 response.json()으로 JavaScript 객체로 변환합니다.",
  },
  {
    category: "React",
    title: "컴포넌트와 JSX",
    keywords: "화면 클래스 UserControl JSX component 컴포넌트",
    description: "컴포넌트는 화면 조각을 반환하는 함수이며 이름은 대문자로 시작합니다.",
    csharp: `public class UserCard : UserControl\n{\n    public string Name { get; set; }\n}`,
    react: `function UserCard() {\n  return (\n    <section>\n      <h2>사용자 카드</h2>\n    </section>\n  );\n}\n\nexport default UserCard;`,
    point: "return 안의 HTML처럼 보이는 문법이 JSX입니다. class 대신 className을 사용합니다.",
  },
  {
    category: "React",
    title: "Props",
    keywords: "매개변수 속성 전달 부모 자식 props",
    description: "부모 컴포넌트가 자식 컴포넌트에 전달하는 읽기 전용 입력값입니다.",
    csharp: `var card = new UserCard();\ncard.Name = "병찬";`,
    react: `function UserCard({ name }) {\n  return <h2>{name}</h2>;\n}\n\n<UserCard name="병찬" />`,
    point: "자식 컴포넌트는 전달받은 Props를 직접 변경하지 않습니다.",
  },
  {
    category: "React",
    title: "State와 useState",
    keywords: "필드 값 변경 state useState setter 화면 갱신",
    description: "화면에 표시되는 변경 값을 보관하며 setter 호출 시 화면을 다시 그립니다.",
    csharp: `private int count = 0;\n\nprivate void Button_Click(...)\n{\n    count++;\n    CountLabel.Text = count.ToString();\n}`,
    react: `const [count, setCount] = useState(0);\n\nfunction handleClick() {\n  setCount(count + 1);\n}\n\n<button onClick={handleClick}>{count}</button>`,
    point: "count를 직접 변경하지 말고 반드시 setCount 같은 setter를 사용합니다.",
  },
  {
    category: "React",
    title: "이벤트 처리",
    keywords: "Click Change 이벤트 onClick onChange 핸들러 버튼",
    description: "이벤트 이름은 camelCase이고 실행할 함수 자체를 중괄호로 전달합니다.",
    csharp: `private void SaveButton_Click(object sender, EventArgs e)\n{\n    Save();\n}`,
    react: `function handleSave() {\n  save();\n}\n\n<button onClick={handleSave}>저장</button>`,
    point: "onClick={handleSave()}가 아니라 onClick={handleSave}로 전달합니다.",
  },
  {
    category: "React",
    title: "조건부·목록 렌더링",
    keywords: "Visible ItemsSource map key 조건 화면 표시 목록",
    description: "조건에 따라 JSX를 표시하고 배열은 map으로 화면 요소로 변환합니다.",
    csharp: `panel.Visible = isLogin;\nlistBox.ItemsSource = users;`,
    react: `{isLogin && <UserPanel />}\n\n{users.map((user) => (\n  <UserCard key={user.id} name={user.name} />\n))}`,
    point: "목록의 key에는 변하지 않는 고유 ID를 사용합니다.",
  },
  {
    category: "React",
    title: "useEffect",
    keywords: "Loaded 생명주기 값 변경 감지 useEffect",
    description: "화면이 나타나거나 지정한 값이 바뀐 뒤 실행할 작업을 정의합니다.",
    csharp: `private async void Window_Loaded(...)\n{\n    await LoadData();\n}`,
    react: `useEffect(() => {\n  loadData();\n}, []);\n\nuseEffect(() => {\n  console.log(selectedId);\n}, [selectedId]);`,
    point: "[]는 최초 한 번, [selectedId]는 selectedId 변경 시 실행한다는 뜻입니다.",
  },
];

const categories = ["전체", "JavaScript", "React"];

// Props로 label과 code를 전달받는 재사용 컴포넌트입니다.
function CodeBlock({ label, code, language }) {
  const [copied, setCopied] = useState(false);

  async function handleCopy() {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1200);
  }

  return (
    <div className={`code-panel ${language}`}>
      <div className="code-header">
        <span>{label}</span>
        <button onClick={handleCopy}>{copied ? "복사됨" : "복사"}</button>
      </div>
      <pre><code>{code}</code></pre>
    </div>
  );
}

// useState와 이벤트를 직접 확인하는 예제 컴포넌트입니다.
function CounterPractice() {
  const [count, setCount] = useState(0);
  const [step, setStep] = useState(1);

  return (
    <section className="practice" id="practice">
      <div className="practice-description">
        <p className="eyebrow">직접 작동해보기</p>
        <h2>State + 이벤트 실습</h2>
        <p>버튼을 누르면 setter가 값을 변경하고 React가 숫자를 다시 표시합니다.</p>
      </div>

      <div className="counter-card">
        <div className="counter-value">{count}</div>
        <div className="step-buttons">
          <span>증가 단위</span>
          {[1, 5, 10].map((value) => (
            <button
              key={value}
              className={step === value ? "selected" : ""}
              onClick={() => setStep(value)}
            >
              {value}
            </button>
          ))}
        </div>
        <div className="counter-buttons">
          <button onClick={() => setCount((current) => current - step)}>− {step}</button>
          <button className="primary" onClick={() => setCount((current) => current + step)}>+ {step}</button>
          <button onClick={() => setCount(0)}>초기화</button>
        </div>
      </div>

      <CodeBlock
        label="현재 실습의 핵심 코드"
        language="js"
        code={`const [count, setCount] = useState(0);\nconst [step, setStep] = useState(1);\n\n<button onClick={() => setCount(count + step)}>\n  + {step}\n</button>`}
      />
    </section>
  );
}

export default function App() {
  // 검색어와 선택된 카테고리는 변경 시 화면이 바뀌므로 State로 선언합니다.
  const [searchText, setSearchText] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("전체");

  // 검색어나 카테고리가 변경될 때만 필터 결과를 다시 계산합니다.
  const filteredItems = useMemo(() => {
    const keyword = searchText.trim().toLowerCase();

    return guideItems.filter((item) => {
      const categoryMatched =
        selectedCategory === "전체" || item.category === selectedCategory;

      const searchableText =
        `${item.title} ${item.keywords} ${item.description} ${item.point}`.toLowerCase();

      const keywordMatched = !keyword || searchableText.includes(keyword);
      return categoryMatched && keywordMatched;
    });
  }, [searchText, selectedCategory]);

  return (
    <main>
      <header className="topbar">
        <a className="brand" href="#top"><span>R</span> React Guide</a>
        <nav>
          <a href="#dictionary">문법 사전</a>
          <a href="#practice">실습</a>
          <a href="#flow">작성 순서</a>
        </nav>
      </header>

      <section className="hero" id="top">
        <div>
          <p className="eyebrow">C# 개발자의 빠른 번역 사전</p>
          <h1>C#으로 생각하고,<br /><em>React로 옮겨 쓰기.</em></h1>
          <p className="hero-text">
            모르는 기능의 이름을 검색하고 C# 코드와 JavaScript/React 코드를 비교하세요.
          </p>
          <div className="search-box">
            <span>⌕</span>
            <input
              value={searchText}
              onChange={(event) => setSearchText(event.target.value)}
              placeholder="예: foreach, 버튼 클릭, 값 변경, API..."
            />
            {searchText && <button onClick={() => setSearchText("")}>×</button>}
          </div>
        </div>

        <aside className="mental-model">
          <p className="eyebrow">가장 먼저 기억할 것</p>
          <div><span>C# 화면 클래스</span><b>→</b><strong>컴포넌트</strong></div>
          <div><span>메서드 매개변수</span><b>→</b><strong>Props</strong></div>
          <div><span>화면에 표시할 필드</span><b>→</b><strong>State</strong></div>
          <div><span>Click 이벤트</span><b>→</b><strong>onClick</strong></div>
          <div><span>LINQ Select / Where</span><b>→</b><strong>map / filter</strong></div>
        </aside>
      </section>

      <section className="dictionary" id="dictionary">
        <div className="section-header">
          <div>
            <p className="eyebrow">Syntax dictionary</p>
            <h2>기능 이름부터 찾는 문법 사전</h2>
          </div>
          <div className="category-buttons">
            {categories.map((category) => (
              <button
                key={category}
                className={selectedCategory === category ? "active" : ""}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        <p className="result-count">{filteredItems.length}개 항목</p>
        <div className="guide-list">
          {filteredItems.map((item, index) => (
            <article className="guide-item" key={item.title}>
              <div className="guide-title">
                <span>{String(index + 1).padStart(2, "0")}</span>
                <div>
                  <small>{item.category}</small>
                  <h3>{item.title}</h3>
                  <p>{item.keywords.replaceAll(" ", " · ")}</p>
                </div>
              </div>
              <div>
                <p className="description">{item.description}</p>
                <div className="code-grid">
                  <CodeBlock label="C#에서" code={item.csharp} language="cs" />
                  <CodeBlock label="JavaScript / React에서" code={item.react} language="js" />
                </div>
                <p className="point"><span>POINT</span>{item.point}</p>
              </div>
            </article>
          ))}

          {filteredItems.length === 0 && (
            <div className="empty-result">일치하는 항목이 없습니다.</div>
          )}
        </div>
      </section>

      <CounterPractice />

      <section className="flow" id="flow">
        <p className="eyebrow">React 사고 순서</p>
        <h2>화면 하나를 작성할 때</h2>
        <ol>
          <li><span>01</span><div><strong>컴포넌트를 함수로 만든다</strong><p>이름을 대문자로 시작합니다.</p></div></li>
          <li><span>02</span><div><strong>변경될 값을 State로 정한다</strong><p>화면에 표시되며 바뀌는 값만 담습니다.</p></div></li>
          <li><span>03</span><div><strong>이벤트 함수를 만든다</strong><p>클릭이나 입력 시 setter를 호출합니다.</p></div></li>
          <li><span>04</span><div><strong>JSX에서 연결한다</strong><p>중괄호로 값과 함수를 연결합니다.</p></div></li>
        </ol>
      </section>

      <footer>필요한 예제를 하나씩 추가하는 개인 React 참고서</footer>
    </main>
  );
}
